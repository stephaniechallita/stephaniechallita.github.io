package test;

import org.junit.Test;

import types.Tableau;
import static org.junit.Assert.*;

public class TUUnion extends ATU {
	
	@Test
	public void testUnion() {
		Tableau<Integer> union = this.smallTab.union(this.smallTab);
		for (int i = 0 ; i < this.smallTab.size() ; i++) {
			assertTrue(union.contains(i));
		}
		assertEquals(this.smallTab.size()*2, union.size());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testUnionOnEmpty() {
		Tableau<Integer> union = this.emptyTab.union(this.smallTab);
		for (int i = 0 ; i < this.smallTab.size() ; i++) {
			assertTrue(union.contains(i));
		}
		assertEquals(this.smallTab.size(), union.size());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testUnionEmpty() {
		Tableau<Integer> union = this.smallTab.union(this.emptyTab);
		for (int i = 0 ; i < this.smallTab.size() ; i++) {
			assertTrue(union.contains(i));
		}
		assertEquals(this.smallTab.size(), union.size());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testUnionEmptyOnEmpty() {
		Tableau<Integer> union = this.emptyTab.union(this.emptyTab);
		assertTrue(union.empty());
		this.checkIntegrityOfVariables();
	}
	

}
