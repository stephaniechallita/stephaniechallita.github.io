package test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import types.Block;

public class BlockEstSousTableauTest {

	@Test
	public void testExemple1() {
		char[] valuesa = new char[] { 'c', 'a', 'x', 'b', 'b', 'x', 'a', 'b', 'c' };
		Block<Character> a = new Block<>(valuesa.length);
		for (int i = 0 ; i < valuesa.length ; i++) {
			a.push_back(valuesa[i]);
		}
		char[] valuesb = new char[] { 'a', 'b', 'a', 'c' };
		Block<Character> b = new Block<>(valuesb.length);
		for (int i = 0 ; i < valuesb.length ; i++) {
			b.push_back(valuesb[i]);
		}
		assertTrue(a.estSousTableau(b));
	}
	
	@Test
	public void testExemple1WrongOrder() {
		char[] valuesa = new char[] { 'c', 'a', 'x', 'b', 'b', 'x', 'a', 'b', 'c' };
		Block<Character> a = new Block<>(valuesa.length);
		for (int i = 0 ; i < valuesa.length ; i++) {
			a.push_back(valuesa[i]);
		}
		char[] valuesb = new char[] { 'a', 'c', 'a', 'b' };
		Block<Character> b = new Block<>(valuesb.length);
		for (int i = 0 ; i < valuesb.length ; i++) {
			b.push_back(valuesb[i]);
		}
		assertFalse(a.estSousTableau(b));
	}
	
	@Test
	public void testExemple2() {
		char[] valuesa = new char[] { 'b', 'a', 'x', 'c', 'a', 'x' };
		Block<Character> a = new Block<>(valuesa.length);
		for (int i = 0 ; i < valuesa.length ; i++) {
			a.push_back(valuesa[i]);
		}
		char[] valuesb = new char[] { 'a', 'b', 'a', 'c' };
		Block<Character> b = new Block<>(valuesb.length);
		for (int i = 0 ; i < valuesb.length ; i++) {
			b.push_back(valuesb[i]);
		}
		assertFalse(a.estSousTableau(b));
	}
	
	@Test
	public void testExemple3() {
		char[] valuesa = new char[] { 'a', 'x', 'a', 'b', 'b' };
		Block<Character> a = new Block<>(valuesa.length);
		for (int i = 0 ; i < valuesa.length ; i++) {
			a.push_back(valuesa[i]);
		}
		char[] valuesb = new char[] { 'a', 'b', 'a', 'c' };
		Block<Character> b = new Block<>(valuesb.length);
		for (int i = 0 ; i < valuesb.length ; i++) {
			b.push_back(valuesb[i]);
		}
		assertFalse(a.estSousTableau(b));
	}
	
	@Test
	public void testEmpty() {
		char[] valuesa = new char[] { 'a', 'x', 'a', 'b', 'b' };
		Block<Character> a = new Block<>(valuesa.length);
		for (int i = 0 ; i < valuesa.length ; i++) {
			a.push_back(valuesa[i]);
		}
		Block<Character> b = new Block<>(1);
		assertTrue(a.estSousTableau(b));
	}
	
	@Test
	public void testOnEmpty() {
		Block<Character> a = new Block<>(1);
		char[] valuesb = new char[] { 'a', 'b', 'a', 'c' };
		Block<Character> b = new Block<>(valuesb.length);
		for (int i = 0 ; i < valuesb.length ; i++) {
			b.push_back(valuesb[i]);
		}
		assertFalse(a.estSousTableau(b));
	}
}
