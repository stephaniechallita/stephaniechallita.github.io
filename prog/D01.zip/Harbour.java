package fr.esir.prog.d01;

import fr.esir.prog.d01.ships.Ship;
/**
 * Cette classe represente un port
 */
public class Harbour {
    /**
     * Instancie un nouveau port
     * @param size taille du port
     */
    public Harbour(int size) {
        ...
    }
    /**
     * Ajoute un nouveau bateau au port, si celui-ci a suffisamment de place.
     * @param ship le bateau a ajouter
     */
    public void add(Ship ship) {
        ...
    }
    /**
     * Verifie si le bateau fourni peut etre ajoute
     * @param ship le bateau que l'on souhaite ajouter
     * @return true si le bateau peut etre ajoute, faux sinon
     */
    public boolean canAdd(Ship ship) {
        ...
    }
    /**
     * calcul la charge d'un port
     * @return la charge actuelle du port
     */
    public int getLoad() {
        ...
    }
    /**
     * Construit le manifeste du port, c'est a dire la liste des bateaux qui l'occupent
     * @return le manisfeste sous forme de string
     */
    public String buildManifest() {
        ...
    }
}