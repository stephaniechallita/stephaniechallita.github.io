package fr.esir.prog.d01.ships;

/**
 * Cette interface represente un bateau quelconque.
 */
public interface Ship {

    /**
     * Retourne la taille du bateau
     * @return la taille du bateau
     */
    public int getSize();

    /**
     * Retourne le nom du bateau
     * @return le nom du bateau
     */
    public String getName();

    /**
     * Retourne le type du bateau
     * @return le type du bateau
     */
    public String getType();

}
