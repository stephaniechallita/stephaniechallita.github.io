package rationnel;

import java.text.DecimalFormat;

import types.Rationnel;

/**
 * Implémentation du TA Rationnel
 *
 * Created: Fri Nov 12 09:39:27 2004
 *
 * @author <a href="mailto:Jean-Christophe.Engel@irisa.fr">Jean-Christophe Engel</a>
 * @version 1.2
 */

public class RationnelSimple implements Rationnel
{

  // attributs : une fraction est représentée par un numérateur et un dénominateur
  private	int numerateur, denominateur;

  /**
   * initialiser un rationnel à partir d'un entier : nb/1
   * @param num : valeur du numérateur
   */
  public RationnelSimple(int num) {
    // System.out.print("RationnelSimple(" + num + ",1) ");
    setNumerateur(num) ; setDenominateur(1);
  }

  /**
   * initialiser un rationnel avec numerateur et dénominateur
   * résultat : fraction irréductible de dénominateur > 0
   * @param num : numérateur
   * @param den : dénominateur
   * @pre den != 0
   * @post fraction irréductible et den > 0
   */
  public RationnelSimple(int num, int den) {
    assert den != 0 : "*** ERREUR constructeur : dénominateur = 0 ***";
    // System.out.print("RationnelSimple(" + num + "," + den + ") ");
    setNumerateur(num) ; setDenominateur(den);
    normaliser();
  }

  /**
   * initialiser un rationnel un rationnel à partir d'un autre
   * @param r : rationnel à dupliquer
   */
  public RationnelSimple(Rationnel r) {
    setNumerateur(r.getNumerateur());
    setDenominateur(r.getDenominateur());
    // System.out.print("RationnelSimple(" + getNumerateur() + "," + getDenominateur() + ") ");
  }

  /**
   * égalité de deux rationnels
   * @param r : rationnel à comparer au rationnel courant
   * @return vrai si le rationnel courant est égal au rationnel paramètre
   */
  public boolean equals(Rationnel r)
  {
    return getNumerateur() == r.getNumerateur() && getDenominateur() == r.getDenominateur();
  }

  // le vrai equals appelé par les algorithmes de la bibliothèque java
  public boolean equals(Object o)
  {
    if (o instanceof Rationnel)
    {
      Rationnel r = ((Rationnel) o);
      return this.equals(r);
    }
    else { return false; }
  }
  
  /**
   * somme de deux rationnels
   * @param r : rationnel à additionner avec le rationnel courant
   * @return nouveau Rationnel somme du rationnel courant et du rationnel paramètre
   */
  public Rationnel somme(Rationnel r) {
    return new RationnelSimple(getNumerateur() * r.getDenominateur() +
                               r.getNumerateur() * getDenominateur(),
                               getDenominateur() * r.getDenominateur());
  }

  /**
   * inverse du rationnel courant
   * @return nouveau Rationnel inverse du rationnel courant
   * @pre numérateur != 0
   */
  public Rationnel inverse() {
    assert getNumerateur() != 0 : "*** ERREUR inverse() : numérateur = 0 ***";
    return new RationnelSimple(getDenominateur(), getNumerateur());
  }

  /**
   * calcule la valeur réelle du rationnel courant
   * @return valeur réelle du rationnel courant
   */
  public double valeur() {
    return (double) getNumerateur()/(double)getDenominateur();
  }

  /**
   * 'toString'er un rationnel
   @return représentation affichable d'un rationnel
  */
  public String toString()
  {
    String sortie = "" + getNumerateur();
    if (getDenominateur() != 1) {
      sortie += "/" + getDenominateur();
    }
    DecimalFormat df = new DecimalFormat("###.###");
    // sortie += " (" + df.format(valeur()) + ")";
    return sortie;
  }

  // accesseurs
  public int getNumerateur()            { return numerateur; }
  public int getDenominateur()          { return denominateur; }
  protected void setNumerateur(int n)   { numerateur   = n; }
  protected void setDenominateur(int d) { denominateur = d; }

  // méthode de l'interface Comparable<Rationnel>
  public int compareTo(Rationnel autre) {
    return getNumerateur() * autre.getDenominateur() - autre.getNumerateur() * getDenominateur();
  }

  // méthodes et fonctions privées de l'implémentation

  /**
   * normalise une fraction rationnelle
   * rend son dénominateur > 0 et rend la fraction irréductible
   */
  protected void normaliser() {
    if (getNumerateur() == 0) { setDenominateur(1); }
    else {
      int monpgcd = util.Outils.pgcd(Math.abs(getNumerateur()),
				     Math.abs(getDenominateur()));
      setNumerateur(getNumerateur() / monpgcd);
      setDenominateur(getDenominateur() / monpgcd);

      if (getDenominateur() < 0) {
        setNumerateur(-1 * getNumerateur());
        setDenominateur(-1 * getDenominateur());
      }
    }
  } // normaliser

}// RationnelSimple
