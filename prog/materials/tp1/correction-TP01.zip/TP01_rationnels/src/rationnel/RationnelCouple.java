package rationnel;
import util.Couple;
import types.Rationnel;

/**
 * Implémentation du TA Rationnel
 *
 * Created: Fri Nov 12 09:39:27 2004
 *
 * @author <a href="mailto:Jean-Christophe.Engel@irisa.fr">Jean-Christophe Engel</a>
 * @version 1.2
 */

public class RationnelCouple implements Rationnel
{

  // attributs : une fraction est représentée par un couple d'entiers
  private	Couple<Integer, Integer> valeur;

  /**
   * initialiser un rationnel à partir d'un entier : nb/1
   * @param num : valeur du numérateur
   */
  public RationnelCouple(int num) {
    // System.out.print("RationnelCouple(" + num + ",1) ");
    valeur = new Couple<Integer, Integer>(num, 1);
  }

  /**
   * initialiser un rationnel avec numerateur et dénominateur
   * résultat : fraction irréductible de dénominateur > 0
   * @param num : numérateur
   * @param den : dénominateur
   * @pre den != 0
   * @post fraction irréductible et den > 0
   */
  public RationnelCouple(int num, int den) {
    assert den != 0 : "*** ERREUR constructeur : dénominateur = 0 ***";
    valeur = new Couple<Integer, Integer>(num, den);
    // System.out.print("RationnelCouple(" + num + "," + den + ") ");
    normaliser();
  }

  /**
   * initialiser un rationnel un rationnel à partir d'un autre
   * @param r : rationnel à dupliquer
   */
  public RationnelCouple(Rationnel r) {
    valeur = new Couple<Integer, Integer>(r.getNumerateur(), r.getDenominateur());
    // System.out.print("RationnelCouple(" + getNumerateur() + "," + getDenominateur() + ") ");
  }

  /**
   * égalité de deux rationnels
   * @param r : rationnel à comparer au rationnel courant
   * @return vrai si le rationnel courant est égal au rationnel paramètre
   */
  public boolean equals(Rationnel r) {
    return getNumerateur() == r.getNumerateur() && getDenominateur() == r.getDenominateur();
  }

  /**
   * somme de deux rationnels
   * @param r : rationnel à additionner avec le rationnel courant
   * @return nouveau Rationnel somme du rationnel courant et du rationnel paramètre
   */
  public Rationnel somme(Rationnel r) {
    return new RationnelCouple(getNumerateur() * r.getDenominateur() +
                               r.getNumerateur() * getDenominateur(),
                               getDenominateur() * r.getDenominateur());
  }

  /**
   * inverse du rationnel courant
   * @return nouveau Rationnel inverse du rationnel courant
   * @pre numérateur != 0
   */
  public Rationnel inverse() {
    assert getNumerateur() != 0 : "*** ERREUR inverse() : numérateur = 0 ***";
    return new RationnelCouple(getDenominateur(), getNumerateur());
  }

  /**
   * calcule la valeur réelle du rationnel courant
   * @return valeur réelle du rationnel courant
   */
  public double valeur() {
    return (double) getNumerateur()/(double)getDenominateur();
  }

  /**
   * 'afficher' un rationnel
   @return représentation affichable d'un rationnel
  */
  public String toString() {
    if (getDenominateur() == 1) {
      return "" + getNumerateur();
    } else {
      return "" + getNumerateur() + "/" + getDenominateur();
    }
  }

  // accesseurs
  public int getNumerateur()            { return valeur.getFirst(); }
  public int getDenominateur()          { return valeur.getSecond(); }
  private void setNumerateur(int n)     { valeur.setFirst(n); }
  private void setDenominateur(int d)   { valeur.setSecond(d); }

  // méthode de l'interface Comparable<Rationnel>
  public int compareTo(Rationnel autre) {
    return getNumerateur() * autre.getDenominateur() - autre.getNumerateur() * getDenominateur();
  }

  // méthodes et fonctions privées de l'implémentation

  /**
   * normalise une fraction rationnelle
   * rend son dénominateur > 0 et rend la fraction irréductible
   */
  private void normaliser() {
    if (getNumerateur() == 0) { setDenominateur(1); }
    else {
      int monpgcd = util.Outils.pgcd(Math.abs(getNumerateur()),
				     Math.abs(getDenominateur()));
      setNumerateur(getNumerateur() / monpgcd);
      setDenominateur(getDenominateur() / monpgcd);

      if (getDenominateur() < 0) {
        setNumerateur(-1 * getNumerateur());
        setDenominateur(-1 * getDenominateur());
      }
    }
  } // normaliser

}// RationnelCouple
