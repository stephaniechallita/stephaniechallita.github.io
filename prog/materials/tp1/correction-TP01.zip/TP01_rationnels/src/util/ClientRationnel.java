package util;

import java.util.Scanner;

import rationnel.RationnelCouple;
import rationnel.RationnelSimple;
import types.Rationnel;

/**
 * ClientRationnel.java
 *
 * Created: Fri Nov 12 10:20:21 2004
 *
 * @author <a href="mailto:Jean-Christophe.Engel@irisa.fr">Jean-Christophe Engel</a>
 * @version
 */

public class ClientRationnel
{

  public static void main (String[] args)
  {
    Scanner input = new Scanner(System.in);
    Rationnel [] lesRationnels = new Rationnel[1000];
    int nbRationnels = 0;
    Rationnel precedent = makeRationnel(0, 1);

    System.out.println("Donnez une suite de rationnels");
    System.out.println("Pour terminer, donnez un rationnel de valeur nulle");
    while (nbRationnels < lesRationnels.length - 3)
      {
        Rationnel courant = lireRationnel(input);
        if (courant.valeur() == 0) { break; }

        // afficher le rationnel lu et le mettre dans le tableau
        System.out.print("courant = " + courant + " ; ");
        insererRationnel(courant, lesRationnels, nbRationnels);
        ++nbRationnels;

        // somme du courant et du precedent
        insererRationnel(courant.somme(precedent), lesRationnels, nbRationnels);
        System.out.print(courant + " + " + precedent + " = " + lesRationnels[nbRationnels] + " ; ");
        ++nbRationnels;

        // inverse
        if (courant.getNumerateur() != 0) {
          insererRationnel(courant.inverse(), lesRationnels, nbRationnels);
          System.out.print("inverse = " + lesRationnels[nbRationnels] + " ; ");
          ++nbRationnels;
        }
        // valeur
        System.out.print("valeur = " + courant.valeur() + " ; ");

        System.out.print(courant);
        int compare = courant.compareTo(precedent);
        if (compare < 0) {
          System.out.print(" <  ");
        }
        else if (compare > 0) {
          System.out.print(" > ");
        }
        if (courant.equals(precedent)) {
          System.out.print(" = ");
        }
        System.out.println(precedent.toString());
        precedent = courant;
      }
    // afficher le contenu du tableau
    afficher(lesRationnels, nbRationnels);
    // calculer et afficher la somme de tous les rationnels du tableau
    Rationnel sommeTableau = sommeRationnels(lesRationnels, nbRationnels);
    System.out.println("\nSomme des rationnels du tableau = " + sommeTableau + " ; valeur = " + sommeTableau.valeur());
  }

  /**
   * saisie d'un rationnel
   * @param  input = scanner où se fait la lecture
   * @return un rationnel initialisé par saisie
   */
  static Rationnel lireRationnel(Scanner input)
  {
    int  num = input.nextInt();
    int  den = input.nextInt();
    return makeRationnel(num, den);
  }

  /**
   * insérer un rationnel dans un tableau 
   * @param nouveau : rationnel à insérer dans le tableau
   * @param lesRationnels :  tableau trié
   * @pre  : éléments du tableau classés en ordre croissant
   * @param nbRationnels  : nombre d'éléments dans le tableau
   * @pre  : 0 <= nbRationnels < lesRationnels.length
   * @post : éléments du tableau classés en ordre croissant
   */
  public static void
    insererRationnel(Rationnel nouveau,
		     Rationnel [] lesRationnels,
		     int nbRationnels)
  {
    // chercher en partant de la fin le premier rationnel <= nouveau
    int nt = nbRationnels;      // nombre d'élts restant à traiter
				// les élts d'indice > nt sont > nouveau
				// nt est aussi l'indice du "trou"
    while (nt > 0) {
      // il reste au moins un élément à traiter
      if (nouveau.compareTo(lesRationnels[nt - 1]) < 0) {
        // décaler l'élt nt-1 dans le trou
        lesRationnels[nt] = lesRationnels[nt - 1];
        nt -= 1;
      }
      else { break ; } // lesRationnels[nt - 1] <= nouveau
    }
    // 2 cas d'arrêt : 
    // nt = 0 => nouveau < tous les élts du tableau => ajout en nt
    // nt > 0 => lesRationnels[nt-1] <= nouveau => ajout en nt
    // les élts d'indice > nt sont > nouveau
    lesRationnels[nt] = nouveau;
  }

  /**
   * Calculer la somme de tous les rationnels du tableau
   * @param lesRationnels : tableau (non modifié)
   * @param nbRationnels  : nombre d'éléments dans le tableau
   * @pre 0 <= nbRationnels <= lesRationnels.length
   * @return nouveau rationnel, somme des éléments du tableau
   */
  public static Rationnel sommeRationnels(Rationnel [] lesRationnels, int nbRationnels)
  {
    Rationnel somme = makeRationnel(0, 1);
    System.out.println("somme = " + somme);
    for (int i = 0; i < nbRationnels; ++i) {
      somme = lesRationnels[i].somme(somme);
      System.out.println("somme = " + somme);
    }
    return somme;
  }

  /**
   * Afficher les rationnels d'un tableau
   * @param lesRationnels
   * @param nbRationnels
   * @pre 0 <= nbRationnels <= lesRationnels.length
   */
  static void afficher(Rationnel [] lesRationnels, int nbRationnels)
  {
    for (int i = 0; i < nbRationnels; ++i) {
      System.out.println("" + i + " : " + lesRationnels[i] + " (" + lesRationnels[i].valeur() + ")");
    }
  }

  /**
     Fabrication de rationnels
  */
  static Rationnel makeRationnel(int num, int den)
  {
    if (num % 2 == 0) {
      return new RationnelSimple(num, den);
    }  else {
      return new RationnelCouple(num, den);
    }
  }

}// clientRationnel
