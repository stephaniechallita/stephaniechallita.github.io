package util;

/**
   type Couple ; T1 et T2 sont les types des deux composantes

   @pre pour pouvoir comparer deux couples avec equals, T1 et T2 doivent
        posséder la méthode equals.
 */
public class Couple<T1,T2>
{
  // représentation
  private T1 comp1;				// 1ère composante
  private T2 comp2;				// 2ème

  /** constructeur
      @param v1 valeur de la première composante
      @param v2 valeur de la deuxième composante
  */
  public Couple(T1 v1, T2 v2) { comp1 = v1; comp2 = v2; }

  /** accès première composante
      @return première composante
  */
  public T1 getFirst() { return comp1; }

  /** accès deuxième composante
      @return deuxième composante
  */
  public T2 getSecond() { return comp2; }

  /** modifier la première composante
      @param v1 nouvelle valeur de la première composante
  */
  public void setFirst(T1 v1) { comp1 = v1; }

  /** modifier la deuxième composante
      @param v2 nouvelle valeur de la deuxième composante
  */
  public void setSecond(T2 v2) { comp2 = v2; }

  /** égalité de deux couples
      @param c : couple à comparer au couple courant
      @return vrai ssi le couple courant est égal au couple paramètre
  */
  public boolean equals(Couple<T1,T2> c) {
    return comp1.equals(c.comp1) && comp2.equals(c.comp2);
  }

  /** représentation d'un couple sous forme de chaîne
      @return représentation d'un couple sous forme de chaîne
  */
  public String toString() {
    return new String("" + comp1.toString() + "," + comp2.toString() + "");
  }
} // Couple<T1, T2>
