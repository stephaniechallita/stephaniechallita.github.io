package main;

import types.Tableau;

public class NombresPremiers {
    public static boolean estPremier(int n, Tableau<Integer> nombresPremiers) {
        return true; // TODO
    }

    public static int calculerNombresPremiers(int n, Tableau<Integer> nombresPremiers) {
        return 2; // TODO
    }

    public static Tableau<Integer> remplirHasard(int nb) {
        return null; // TODO
    }

    public static int eliminerPresents(Tableau<Integer> t, Tableau<Integer> nombresPremiers) {
        return 1; // TODO
    }

    public static boolean estPresent(int x, Tableau<Integer> block, int length) {
        return true; // TODO
    }
}
