package tableau;

import types.Array;
import types.Tableau;

public class Tableau2x<T> implements Tableau<T> {

    public Tableau2x(int capacity) {
        // TODO
    }

    @Override
    public int size() {
        return 0; // TODO
    }

    @Override
    public boolean empty() {
        return true; // TODO
    }

    @Override
    public boolean full() {
        return true; // TODO
    }

    @Override
    public T get(int i) {
        return null; // TODO
    }

    @Override
    public void set(int i, T v) {
        // TODO
    }

    @Override
    public void push_back(T x) {
        // TODO
    }

    @Override
    public void pop_back() {
        // TODO
    }

}