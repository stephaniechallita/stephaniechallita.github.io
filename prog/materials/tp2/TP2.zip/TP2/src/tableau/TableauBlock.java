package tableau;

import types.Array;
import types.Tableau;

public class TableauBlock<T> implements Tableau<T> {

    public TableauBlock(int capacity) {
        // TODO
    }

    public TableauBlock(int capinit, int capabloc){
        // TODO
    }


    @Override
    public int size() {
        return 0; // TODO
    }

    @Override
    public boolean empty() {
        return true; // TODO
    }

    @Override
    public boolean full() {
        return true; // TODO
    }

    @Override
    public T get(int i) {
        return null; // TODO
    }

    @Override
    public void set(int i, T v) {
        // TODO
    }

    @Override
    public void push_back(T x) {
        // TODO
    }

    @Override
    public void pop_back() {
        // TODO
    }


}