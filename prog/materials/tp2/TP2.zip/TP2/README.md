# TP2

Les squelettes des classes Java demandées dans le sujet sont déjà présents dans les bons packages.. Plus qu'à les remplir en suivant les consignes du pdf joint.

## Manuellement

### Dependances

- Ajouter le .jar de junit dans /lib. `junit.jar` peut-être télécharger ici: https://github.com/junit-team/junit4/wiki/Download-and-Install

- Ajouter la dépendance `hamcrest.jar` de la même manière: http://www.java2s.com/Code/Jar/h/Downloadhamcrestcore13jar.htm 

Note: `hamcrest.jar` est aussi sur le dépôt de JUnit.

### Compilation manuelle

Pour compiler correctement les fichiers `.java` , il faut spécifier les dépendances aux archives `.jar`.

Depuis la racine de votre projet, vous pouvez lancer la compilation de `tableau/Block.java` et de `test/TU_Block.java` en spécifiant la dépendance avec `junit-4.13.2.jar` et `types.jar` avec:

`javac -cp lib/types.jar:lib/junit-4.13.2.jar:src src/tableau/Block.java src/test/TU_Block.java`

### Lancer les tests unitaires (TU) manuellement

De la même manière que la compilation, il faut spécifier les dépendances à l'execution.
Pour lancez les tests de `TU_Block.java`,

`java -cp lib/types.jar:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar:src org.junit.runner.JUnitCore test.TU_Block`

### Environnement Java dans VSCode 

Vous pouvez lancer les tests directement via le bouton play depuis VSCode si vous avez installé et activé les extensions `Extension Pack for Java` et  `Test Runner for Java` dans VSCode.

## IntelliJ

/!\ Les nouvelles versions d'IntelliJ embarquent un système d'IA nativement. Pour des raisons pédagogiques, il est très déconseillé de l'utiliser. Ainsi, l'utilisation d'IA pendant les TP notés sera sanctionnée.

### Installation

1. Creer un compte un utilisant votre mail étudiant sur https://account.jetbrains.com/

2. Demandez une licence étudiant/enseignant pour avoir accès aux versions premium des IDE JetBrains https://www.jetbrains.com/student .
Il y a un petit formulaire à remplir, et la réponse n'est pas forcement instantanée.. Heureusement, il y a une version d'essai ;-)

3. Installer IntelliJ Ultimate https://www.jetbrains.com/fr-fr/idea/ . 

### Importer le TP2

1. Ouvrir le dossier du TP avec Intellij.
2. Déclarer le dossier /lib comme contenant des librairies externes (Clique droit sur le dossier lib, puis "Add as library")


### Execution, Compilation, etc.

IntelliJ est un IDE, il va faire pour vous la compilation avec toutes les dépendances associées aux fichiers.

Plus qu'à ouvrir votre fichier `.java` dans l'IDE, et cliquer sur le bouton run (ou debug) dans la class. Et ça... c'est la classe.
