package test;

import org.junit.Test;

import types.Tableau;
import static org.junit.Assert.*;

public class TUMinus extends ATU {
	
	@Test
	public void testMinus() {
		Tableau<Integer> minus = this.smallTab.minus(this.smallTab);
		assertTrue(minus.empty());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testMinus2() {
		Tableau<Integer> minus = this.smallTab.minus(this.largeTab);
		assertTrue(minus.empty());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testMinus3() {
		Tableau<Integer> minus = this.largeTab.minus(this.smallTab);
		for (int i = this.smallTab.size() ; i < this.largeTab.size() ; i++) {
			assertTrue(minus.contains(i));
		}
		assertEquals(this.smallTab.size(), minus.size());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testMinusOnEmpty() {
		Tableau<Integer> minus = this.emptyTab.minus(this.smallTab);
		assertTrue(minus.empty());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testMinusEmpty() {
		Tableau<Integer> minus = this.smallTab.minus(this.emptyTab);
		for (int i = 0 ; i < this.smallTab.size() ; i++) {
			assertTrue(minus.contains(i));
		}
		assertEquals(this.smallTab.size(), minus.size());
		this.checkIntegrityOfVariables();
	}
	
	@Test
	public void testMinusEmptyOnEmpty() {
		Tableau<Integer> minus = this.emptyTab.minus(this.emptyTab);
		assertTrue(minus.empty());
		this.checkIntegrityOfVariables();
	}
	

}
